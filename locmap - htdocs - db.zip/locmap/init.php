


<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "locmap";

$con = mysqli_connect($host, $user, $password, $db);

if(!$con)
{
	die("Error in connection".mysqli_connect_error());
}

else
{
	echo "<br><h3>Connection Success...</h3>";
}

?>