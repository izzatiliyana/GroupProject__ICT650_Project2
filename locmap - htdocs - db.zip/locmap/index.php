<html>

<head><title>Add info..</title></head>
<body>
<form action="add_info.php" method="post">
<table>
<tr> 
<td>PersonName : </td>
<td> <input type = "text" name="personName" > </td>
</tr>



</html>