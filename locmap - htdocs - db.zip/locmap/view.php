<!doctype html>
<html>
<head><title>WELCOME TO LOCMAP!</title></head>
<body>
  <style>
  h1 {text-align: center;}
  body {
    background-image: url('image.jpg');
    background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  }
  table, th, td {
  border: 1px solid black;
}
  </style>


<h1>WELCOME TO LOCMAP!</h1>
<ol>

<table>
  <tr>
    <th>ID</th>
    <th>Person Name</th>
    <th>Email</th>
    <th>Date/Time</th>
    <th>User Agent</th>
    <th>Latitude</th>
    <th>Longitude</th>
    <th>Address</th>
  </tr>

  <?php
  $con = mysqli_connect("localhost","root",'',"locmap");
  $query = "SELECT u.id, u.personName, u.GivenName, u.email, u.date_time, u.user_agent, lo.latitude, lo.longitude, lo.address
  FROM user u, location lo WHERE u.id = lo.loc_id";
  $result=mysqli_query($con,$query);

  if ($result-> num_rows > 0) {
  	while ($row = $result-> fetch_assoc()) {
  		echo "<tr><td>". $row["id"] ."</td><td>". $row["personName"]."</td><td>". $row["email"]."</td><td>". $row["date_time"]."</td><td>". $row["user_agent"]."</td><td>". $row["latitude"]."</td><td>". $row["longitude"]."</td><td>". $row["address"]."</td></tr>";
      }
      echo "</table>";
    }
    else {
      echo "0 result";
    }


    ?>
</table>

</ol>

</body>
</html>
