<?php

require "init.php";

$loc_id = $_POST["loc_id"];
$lati = $_POST["lati"];
$longi = $_POST["longi"];
$address = $_POST["address"];


$sql = "INSERT INTO location VALUES('$loc_id','$lati','$longi','$address',NOW());";

if(mysqli_query($con, $sql))
{
	echo "<br><h3>One Row Inserted...</h3>";
}

else
{
	echo "Error....".mysqli_error($con);
}


?>