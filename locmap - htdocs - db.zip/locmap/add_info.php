<?php

require "init.php";

$id = $_POST["id"];
$personName = $_POST["personName"];
$email = $_POST["email"];
$GivenName = $_POST["GivenName"];
$agent = $_SERVER['HTTP_USER_AGENT'];


$sql = "INSERT INTO user VALUES('$id','$personName','$email','$GivenName',NOW(),'$agent');";

if(mysqli_query($con, $sql))
{
	echo "<br><h3>One Row Inserted...</h3>";
}

else
{
	echo "Error....".mysqli_error($con);
}


?>